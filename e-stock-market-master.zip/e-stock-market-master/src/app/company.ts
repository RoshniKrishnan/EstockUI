export class company{
    companyId?:number;
    companyCode?: string;
    companyName?: string;
    companyOwner?: string;
    companyTurnover?: number;
    website?: string;
    stockExchangeType?: number;
   latestStockPrice?: number;
}