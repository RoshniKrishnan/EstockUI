import { stock } from "./stock";

export class stockDetails {
    minStockPrice?: number;
    maxStockPrice?: number;
    avgStockPrice?: number;
}